---
name: Question
about: "For questions: please go to the discussions section!"
title: "[Q]"
labels: question
assignees: ""
---

**For questions: please go to the [discussions section](https://github.com/mathieucarbou/ESPAsyncWebServer/discussions)!**